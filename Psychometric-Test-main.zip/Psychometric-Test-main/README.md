# Psychometric-Test
An adaptive learning model to conduct psychometric test and predicting possible career options by using clustering algorithms.
